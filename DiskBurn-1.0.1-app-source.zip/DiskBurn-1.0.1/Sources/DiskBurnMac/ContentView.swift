// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 DiskBurn contributors
// DiskBurn macOS port, derived from Asunder 3.0.1.
import AppKit
import SwiftUI

@MainActor
final class DiscViewModel: ObservableObject {
    @Published var albumArtist = ""
    @Published var albumTitle = ""
    @Published var genre = ""
    @Published var year = ""
    @Published var singleArtist = true
    @Published var tracks: [CDTrack] = []
    @Published var status = "Insert an audio CD, then click Refresh."
    @Published var isRefreshing = false
    @Published var isFetchingMetadata = false
    @Published var showRippingProgress = false
    @Published var errorMessage: String?
    @Published var showAbout = false
    let ripper = RippingService()
    private var leadoutFrame = 0
    private var devicePath: String?

    var snapshot: DiscSnapshot {
        DiscSnapshot(artist: albumArtist, title: albumTitle, genre: genre, year: year, tracks: tracks, leadoutFrame: leadoutFrame, devicePath: devicePath)
    }

    func refresh() {
        guard !isRefreshing else { return }
        isRefreshing = true
        status = "Reading disc…"
        Task {
            do {
                var disc = try await DiscService.readDisc()
                status = "Getting disc information…"
                disc = await CDDBService.applyMetadata(to: disc)
                albumArtist = disc.artist
                albumTitle = disc.title
                genre = disc.genre
                year = disc.year
                tracks = disc.tracks
                leadoutFrame = disc.leadoutFrame
                devicePath = disc.devicePath
                status = "\(tracks.count) tracks ready"
            } catch {
                status = "No disc loaded"
                errorMessage = error.localizedDescription
            }
            isRefreshing = false
        }
    }

    func fetchInformation() {
        guard !tracks.isEmpty, !isFetchingMetadata else { return }
        isFetchingMetadata = true
        status = "Fetching disc information…"
        Task {
            do {
                let disc = try await CDDBService.fetchMetadata(for: snapshot)
                albumArtist = disc.artist
                albumTitle = disc.title
                genre = disc.genre
                year = disc.year
                tracks = disc.tracks
                status = "Disc information updated"
            } catch {
                status = "Metadata lookup failed"
                errorMessage = error.localizedDescription
            }
            isFetchingMetadata = false
        }
    }

    func setAllTracks(_ selected: Bool) {
        for index in tracks.indices { tracks[index].selected = selected }
    }
}

struct ContentView: View {
    @StateObject private var model = DiscViewModel()

    var body: some View {
        VStack(spacing: 0) {
            albumHeader
            Divider()
            trackTable
            Divider()
            bottomBar
        }
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button { model.refresh() } label: { Label("Refresh", systemImage: "arrow.clockwise") }
                    .disabled(model.isRefreshing || model.isFetchingMetadata || model.ripper.isRunning)
                Button { model.fetchInformation() } label: {
                    Label("Fetch Information", systemImage: "text.magnifyingglass")
                }
                .disabled(model.tracks.isEmpty || model.isRefreshing || model.isFetchingMetadata || model.ripper.isRunning)
                SettingsLink { Label("Preferences", systemImage: "gearshape") }
                Button { model.showAbout = true } label: { Label("About", systemImage: "info.circle") }
                    .popover(isPresented: $model.showAbout, arrowEdge: .top) {
                        AboutView()
                    }
            }
        }
        .sheet(isPresented: $model.showRippingProgress) {
            RippingProgressView(ripper: model.ripper) {
                model.showRippingProgress = false
            }
        }
        .alert("DiskBurn", isPresented: Binding(
            get: { model.errorMessage != nil || model.ripper.errorMessage != nil },
            set: { if !$0 { model.errorMessage = nil; model.ripper.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { model.errorMessage = nil; model.ripper.errorMessage = nil }
        } message: {
            Text(model.errorMessage ?? model.ripper.errorMessage ?? "Unknown error")
        }
    }

    private var albumHeader: some View {
        Grid(alignment: .leading, horizontalSpacing: 10, verticalSpacing: 8) {
            GridRow {
                Text("Album Artist:").gridColumnAlignment(.trailing)
                TextField("Artist", text: $model.albumArtist)
                Toggle("Single Artist", isOn: $model.singleArtist)
            }
            GridRow {
                Text("Album Title:").gridColumnAlignment(.trailing)
                TextField("Title", text: $model.albumTitle)
                HStack {
                    TextField("Year", text: $model.year).frame(width: 70)
                    TextField("Genre", text: $model.genre)
                }
            }
        }
        .textFieldStyle(.roundedBorder)
        .padding(14)
    }

    private var trackTable: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Text("Rip").frame(width: 34)
                Text("Track").frame(width: 44, alignment: .leading)
                Text("Artist").frame(maxWidth: .infinity, alignment: .leading)
                Text("Title").frame(maxWidth: .infinity, alignment: .leading)
                Text("Time").frame(width: 62, alignment: .leading)
            }
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(.bar)
            Divider()
            if model.tracks.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "opticaldisc").font(.system(size: 44)).foregroundStyle(.secondary)
                    Text("No Audio CD").font(.title2.weight(.semibold))
                    Text("Connect a drive, insert a disc, and click Refresh.").foregroundStyle(.secondary)
                }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(model.tracks.enumerated()), id: \.element.id) { index, track in
                            HStack(spacing: 8) {
                                Toggle("", isOn: binding(for: track.id, keyPath: \.selected)).labelsHidden().frame(width: 34)
                                Text(String(track.id)).frame(width: 44, alignment: .leading)
                                TextField("Artist", text: binding(for: track.id, keyPath: \.artist))
                                    .textFieldStyle(.plain).disabled(model.singleArtist).frame(maxWidth: .infinity)
                                TextField("Title", text: binding(for: track.id, keyPath: \.title))
                                    .textFieldStyle(.plain).frame(maxWidth: .infinity)
                                Text(track.durationText).monospacedDigit().frame(width: 62, alignment: .leading)
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(index.isMultiple(of: 2) ? Color.clear : Color.secondary.opacity(0.07))
                        }
                    }
                }
            }
        }
    }

    private var bottomBar: some View {
        HStack {
            Button(model.tracks.allSatisfy(\.selected) ? "Select None" : "Select All") {
                model.setAllTracks(!model.tracks.allSatisfy(\.selected))
            }
            .disabled(model.tracks.isEmpty)
            Text(model.status).foregroundStyle(.secondary).lineLimit(1)
            Spacer()
            Button {
                model.ripper.start(snapshot: model.snapshot)
                model.showRippingProgress = true
            } label: {
                Label("Rip", systemImage: "opticaldisc.fill")
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(model.tracks.filter(\.selected).isEmpty || model.ripper.isRunning)
            .keyboardShortcut(.return, modifiers: [.command])
        }
        .padding(12)
    }

    private func binding<Value>(for id: Int, keyPath: WritableKeyPath<CDTrack, Value>) -> Binding<Value> {
        Binding {
            model.tracks.first(where: { $0.id == id })![keyPath: keyPath]
        } set: { value in
            guard let index = model.tracks.firstIndex(where: { $0.id == id }) else { return }
            model.tracks[index][keyPath: keyPath] = value
        }
    }
}

struct RippingProgressView: View {
    @ObservedObject var ripper: RippingService
    let onClose: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("Ripping…", systemImage: "opticaldisc").font(.title2.bold())
            ProgressRow(label: "Total Progress", value: ripper.totalProgress)
            ProgressRow(label: "Ripping", value: ripper.rippingProgress)
            ProgressRow(label: "Encoding", value: ripper.encodingProgress)
            Text(ripper.status).font(.callout).foregroundStyle(.secondary)
            HStack {
                Spacer()
                if ripper.isRunning {
                    Button("Cancel", role: .cancel) { ripper.cancel() }
                        .keyboardShortcut(.cancelAction)
                } else {
                    Button("Close") { onClose() }
                        .keyboardShortcut(.defaultAction)
                }
            }
        }
        .padding(22)
        .frame(width: 420)
        .interactiveDismissDisabled(ripper.isRunning)
    }
}

struct ProgressRow: View {
    let label: String
    let value: Double
    var body: some View {
        HStack {
            Text(label).frame(width: 100, alignment: .trailing)
            ProgressView(value: value)
            Text(value, format: .percent.precision(.fractionLength(0))).monospacedDigit().frame(width: 44)
        }
    }
}

struct AboutView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "opticaldisc.fill").font(.system(size: 64)).foregroundStyle(.tint)
            Text("DiskBurn").font(.largeTitle.bold())
            Text("1.0.1 for macOS ARM64")
            Text("A native macOS audio CD ripper based on Asunder 3.0.1.").foregroundStyle(.secondary)
            Text("Free software · GPL-2.0-only · No warranty")
                .font(.caption)
                .foregroundStyle(.secondary)
            Link("Original Asunder website", destination: URL(string: "http://littlesvr.ca/asunder/")!)
        }
        .padding(32)
        .frame(width: 380)
    }
}
