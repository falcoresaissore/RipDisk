// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 DiskBurn contributors
// DiskBurn macOS port, derived from Asunder 3.0.1.
import SwiftUI
import AppKit

@main
struct DiskBurnApp: App {
    init() {
        Preferences.registerDefaults()
        Appearance.apply(UserDefaults.standard.string(forKey: PreferenceKey.appearance) ?? "system")

        // Set the running application's Dock icon explicitly as well as using
        // CFBundleIconFile. This also avoids a generic icon when Launch
        // Services has cached an older development build of the bundle.
        if let iconURL = Bundle.main.url(forResource: "DiskBurn", withExtension: "icns"),
           let icon = NSImage(contentsOf: iconURL) {
            NSApplication.shared.applicationIconImage = icon
        }
    }

    var body: some Scene {
        WindowGroup("DiskBurn") {
            ContentView()
                .frame(minWidth: 720, minHeight: 500)
        }
        .defaultSize(width: 760, height: 560)

        Settings {
            PreferencesView()
                .frame(width: 620, height: 520)
        }
    }
}
