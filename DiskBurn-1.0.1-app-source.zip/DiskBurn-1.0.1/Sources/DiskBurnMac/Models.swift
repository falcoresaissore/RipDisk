// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 DiskBurn contributors
// DiskBurn macOS port, derived from Asunder 3.0.1.
import Foundation

struct CDTrack: Identifiable, Hashable {
    let id: Int
    var selected = true
    var artist = ""
    var title: String
    var duration: TimeInterval
    var frameOffset: Int

    var durationText: String {
        let seconds = max(0, Int(duration.rounded()))
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}

struct DiscSnapshot {
    var artist = "Unknown Artist"
    var title = "Audio CD"
    var genre = ""
    var year = ""
    var tracks: [CDTrack]
    var leadoutFrame: Int
    var devicePath: String? = nil

    var discID: String {
        let checksum = tracks.reduce(0) { partial, track in
            partial + Self.digitSum(max(0, track.frameOffset / 75))
        }
        let firstSeconds = (tracks.first?.frameOffset ?? 150) / 75
        let length = max(0, leadoutFrame / 75 - firstSeconds)
        let value = ((checksum % 255) << 24) | (length << 8) | tracks.count
        return String(format: "%08x", value)
    }

    private static func digitSum(_ value: Int) -> Int {
        var value = value
        var result = 0
        repeat {
            result += value % 10
            value /= 10
        } while value > 0
        return result
    }
}

enum AudioFormat: String, CaseIterable, Identifiable {
    case wav = "WAV"
    case mp3 = "MP3"
    case ogg = "Ogg Vorbis"
    case flac = "FLAC"
    case opus = "Opus"
    case wavpack = "WavPack"
    case musepack = "Musepack"
    case aac = "AAC"
    case monkeysAudio = "Monkey's Audio"

    var id: String { rawValue }

    var defaultsKey: String { "format.\(String(describing: self))" }

    var executable: String? {
        switch self {
        case .wav: nil
        case .mp3: "lame"
        case .ogg: "oggenc"
        case .flac: "flac"
        case .opus: "opusenc"
        case .wavpack: "wavpack"
        case .musepack: "mpcenc"
        case .aac: "ffmpeg"
        case .monkeysAudio: "mac"
        }
    }

    var pathExtension: String {
        switch self {
        case .wav: "wav"
        case .mp3: "mp3"
        case .ogg: "ogg"
        case .flac: "flac"
        case .opus: "opus"
        case .wavpack: "wv"
        case .musepack: "mpc"
        case .aac: "m4a"
        case .monkeysAudio: "ape"
        }
    }
}
