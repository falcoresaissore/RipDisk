// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 DiskBurn contributors
// DiskBurn macOS port, derived from Asunder 3.0.1.
import AppKit
import Foundation

enum PreferenceKey {
    static let outputDirectory = "outputDirectory"
    static let createPlaylist = "createPlaylist"
    static let ejectWhenFinished = "ejectWhenFinished"
    static let device = "device"
    static let albumDirectoryFormat = "albumDirectoryFormat"
    static let playlistFormat = "playlistFormat"
    static let musicFileFormat = "musicFileFormat"
    static let automaticMetadata = "automaticMetadata"
    static let cddbServer = "cddbServer"
    static let cddbPort = "cddbPort"
    static let cddbIdentity = "cddbIdentity"
    static let fastRip = "fastRip"
    static let logEnabled = "logEnabled"
    static let mp3VBR = "mp3VBR"
    static let mp3Bitrate = "mp3Bitrate"
    static let oggQuality = "oggQuality"
    static let flacCompression = "flacCompression"
    static let opusBitrate = "opusBitrate"
    static let wavpackCompression = "wavpackCompression"
    static let aacBitrate = "aacBitrate"
    static let appearance = "appearance"
}

enum Preferences {
    static func registerDefaults() {
        if UserDefaults.standard.string(forKey: PreferenceKey.cddbIdentity) == nil {
            let uniqueIdentity = UUID().uuidString.lowercased() + "@diskburn.local"
            UserDefaults.standard.set(uniqueIdentity, forKey: PreferenceKey.cddbIdentity)
        }
        if UserDefaults.standard.string(forKey: PreferenceKey.cddbServer) == "gnudb.gnudb.org",
           UserDefaults.standard.integer(forKey: PreferenceKey.cddbPort) == 8880 {
            UserDefaults.standard.set(443, forKey: PreferenceKey.cddbPort)
        }
        UserDefaults.standard.register(defaults: [
            PreferenceKey.outputDirectory: FileManager.default.urls(for: .musicDirectory, in: .userDomainMask).first?.path ?? NSHomeDirectory(),
            PreferenceKey.createPlaylist: true,
            PreferenceKey.ejectWhenFinished: false,
            PreferenceKey.device: "default",
            PreferenceKey.albumDirectoryFormat: "%A - %L",
            PreferenceKey.playlistFormat: "%A - %L",
            PreferenceKey.musicFileFormat: "%N - %A - %T",
            PreferenceKey.automaticMetadata: true,
            PreferenceKey.cddbServer: "gnudb.gnudb.org",
            PreferenceKey.cddbPort: 443,
            PreferenceKey.fastRip: true,
            PreferenceKey.logEnabled: false,
            PreferenceKey.mp3VBR: true,
            PreferenceKey.mp3Bitrate: 190,
            PreferenceKey.oggQuality: 6.0,
            PreferenceKey.flacCompression: 5,
            PreferenceKey.opusBitrate: 160,
            PreferenceKey.wavpackCompression: 1,
            PreferenceKey.aacBitrate: 192,
            PreferenceKey.appearance: "system",
            AudioFormat.ogg.defaultsKey: true
        ])
    }
}

@MainActor
enum Appearance {
    static func apply(_ preference: String) {
        switch preference {
        case "light":
            NSApplication.shared.appearance = NSAppearance(named: .aqua)
        case "dark":
            NSApplication.shared.appearance = NSAppearance(named: .darkAqua)
        default:
            NSApplication.shared.appearance = nil
        }

        for window in NSApplication.shared.windows {
            window.appearance = nil
            window.contentView?.needsDisplay = true
        }
    }
}
