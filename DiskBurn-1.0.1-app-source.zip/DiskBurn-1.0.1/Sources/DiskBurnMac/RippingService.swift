// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 DiskBurn contributors
// DiskBurn macOS port, derived from Asunder 3.0.1.
import Foundation

@MainActor
final class RippingService: ObservableObject {
    @Published var isRunning = false
    @Published var totalProgress = 0.0
    @Published var rippingProgress = 0.0
    @Published var encodingProgress = 0.0
    @Published var status = "Ready"
    @Published var errorMessage: String?

    private var task: Task<Void, Never>?
    private var activeProcess: Process?

    func start(snapshot: DiscSnapshot) {
        guard !isRunning else { return }
        let selected = snapshot.tracks.filter(\.selected)
        guard !selected.isEmpty else {
            errorMessage = "Select at least one track to rip."
            return
        }

        isRunning = true
        totalProgress = 0
        rippingProgress = 0
        encodingProgress = 0
        errorMessage = nil
        task = Task { [weak self] in
            guard let self else { return }
            do {
                try await rip(snapshot: snapshot, tracks: selected)
                status = "Finished"
                if UserDefaults.standard.bool(forKey: PreferenceKey.ejectWhenFinished) {
                    DiscService.eject(devicePath: snapshot.devicePath)
                }
            } catch is CancellationError {
                status = "Cancelled"
            } catch {
                errorMessage = error.localizedDescription
                status = "Failed"
            }
            activeProcess = nil
            isRunning = false
        }
    }

    func cancel() {
        task?.cancel()
        activeProcess?.terminate()
    }

    private func rip(snapshot: DiscSnapshot, tracks: [CDTrack]) async throws {
        guard let ripper = CommandRunner.locate("cd-paranoia") ?? CommandRunner.locate("cdparanoia") else {
            throw RipError.missingTool("bundled cd-paranoia backend")
        }

        let defaults = UserDefaults.standard
        let base = URL(fileURLWithPath: defaults.string(forKey: PreferenceKey.outputDirectory) ?? NSHomeDirectory(), isDirectory: true)
        let albumFolder = render(defaults.string(forKey: PreferenceKey.albumDirectoryFormat) ?? "%A - %L", snapshot: snapshot, track: nil)
        let outputDirectory = base.appendingPathComponent(sanitize(albumFolder), isDirectory: true)
        try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
        let formats = enabledFormats()
        var playlist: [String] = []
        let configuredDevice = defaults.string(forKey: PreferenceKey.device) ?? "default"
        let device = configuredDevice == "default" ? snapshot.devicePath : configuredDevice
        let mountDevice = device?.replacingOccurrences(of: "/dev/rdisk", with: "/dev/disk")

        if let mountDevice {
            _ = try? CommandRunner.run("/usr/sbin/diskutil", ["unmountDisk", mountDevice])
        }
        defer {
            if let mountDevice, !defaults.bool(forKey: PreferenceKey.ejectWhenFinished) {
                _ = try? CommandRunner.run("/usr/sbin/diskutil", ["mountDisk", mountDevice])
            }
        }

        for (index, track) in tracks.enumerated() {
            try Task.checkCancellation()
            status = "Ripping track \(track.id) of \(tracks.count)"
            rippingProgress = 0
            encodingProgress = 0
            let temporary = outputDirectory.appendingPathComponent(".diskburn-\(UUID().uuidString).wav")
            var arguments: [String] = []
            if defaults.bool(forKey: PreferenceKey.fastRip) { arguments.append("-Z") }
            arguments.append("-e")
            if let device { arguments += ["-d", device] }
            arguments += [String(track.id), temporary.path]
            try await run(executable: ripper, arguments: arguments) { [weak self] line in
                guard let self, let percent = Self.percentage(in: line) else { return }
                Task { @MainActor in self.rippingProgress = percent }
            }
            rippingProgress = 1

            let stem = sanitize(render(defaults.string(forKey: PreferenceKey.musicFileFormat) ?? "%N - %A - %T", snapshot: snapshot, track: track))
            let selectedFormats = formats.isEmpty ? [.wav] : formats
            for (formatIndex, format) in selectedFormats.enumerated() {
                try Task.checkCancellation()
                status = "Encoding \(format.rawValue): track \(track.id)"
                let destination = outputDirectory.appendingPathComponent(stem).appendingPathExtension(format.pathExtension)
                try await encode(format, input: temporary, output: destination, snapshot: snapshot, track: track)
                encodingProgress = Double(formatIndex + 1) / Double(selectedFormats.count)
                if format == selectedFormats.first { playlist.append(destination.lastPathComponent) }
            }
            try? FileManager.default.removeItem(at: temporary)
            totalProgress = Double(index + 1) / Double(tracks.count)
        }

        if defaults.bool(forKey: PreferenceKey.createPlaylist), !playlist.isEmpty {
            let name = sanitize(render(defaults.string(forKey: PreferenceKey.playlistFormat) ?? "%A - %L", snapshot: snapshot, track: nil))
            try ("#EXTM3U\n" + playlist.joined(separator: "\n") + "\n").write(
                to: outputDirectory.appendingPathComponent(name).appendingPathExtension("m3u"),
                atomically: true,
                encoding: .utf8
            )
        }
    }

    private func encode(_ format: AudioFormat, input: URL, output: URL, snapshot: DiscSnapshot, track: CDTrack) async throws {
        if format == .wav {
            if FileManager.default.fileExists(atPath: output.path) { try FileManager.default.removeItem(at: output) }
            try FileManager.default.copyItem(at: input, to: output)
            return
        }
        guard let command = format.executable else { return }
        guard let executable = CommandRunner.locate(command) else {
            throw RipError.missingTool("\(command) for \(format.rawValue)")
        }
        let defaults = UserDefaults.standard
        let args: [String]
        switch format {
        case .wav: args = []
        case .mp3:
            args = defaults.bool(forKey: PreferenceKey.mp3VBR)
                ? ["-V", "2", "--tt", track.title, "--ta", track.artist, "--tl", snapshot.title, "--tn", String(track.id), input.path, output.path]
                : ["-b", String(defaults.integer(forKey: PreferenceKey.mp3Bitrate)), input.path, output.path]
        case .ogg:
            args = ["-q", String(defaults.double(forKey: PreferenceKey.oggQuality)), "-t", track.title, "-a", track.artist, "-l", snapshot.title, "-N", String(track.id), "-o", output.path, input.path]
        case .flac:
            args = ["-f", "-\(defaults.integer(forKey: PreferenceKey.flacCompression))", "-T", "TITLE=\(track.title)", "-T", "ARTIST=\(track.artist)", "-T", "ALBUM=\(snapshot.title)", "-T", "TRACKNUMBER=\(track.id)", "-o", output.path, input.path]
        case .opus:
            args = ["--bitrate", String(defaults.integer(forKey: PreferenceKey.opusBitrate)), "--title", track.title, "--artist", track.artist, "--album", snapshot.title, input.path, output.path]
        case .wavpack:
            args = ["-q", "-\(defaults.integer(forKey: PreferenceKey.wavpackCompression))", input.path, "-o", output.path]
        case .musepack:
            args = [input.path, output.path]
        case .aac:
            args = ["-y", "-i", input.path, "-c:a", "aac", "-b:a", "\(defaults.integer(forKey: PreferenceKey.aacBitrate))k", "-metadata", "title=\(track.title)", "-metadata", "artist=\(track.artist)", "-metadata", "album=\(snapshot.title)", "-metadata", "track=\(track.id)", output.path]
        case .monkeysAudio:
            args = [input.path, output.path, "-c3000"]
        }
        try await run(executable: executable, arguments: args, lineHandler: { _ in })
    }

    private func run(executable: String, arguments: [String], lineHandler: @escaping (String) -> Void) async throws {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                let process = Process()
                let pipe = Pipe()
                process.executableURL = URL(fileURLWithPath: executable)
                process.arguments = arguments
                process.standardOutput = pipe
                process.standardError = pipe
                pipe.fileHandleForReading.readabilityHandler = { handle in
                    let data = handle.availableData
                    if !data.isEmpty { lineHandler(String(decoding: data, as: UTF8.self)) }
                }
                process.terminationHandler = { process in
                    pipe.fileHandleForReading.readabilityHandler = nil
                    if process.terminationStatus == 0 {
                        continuation.resume()
                    } else {
                        continuation.resume(throwing: RipError.commandFailed(executable, process.terminationStatus))
                    }
                }
                do {
                    try process.run()
                    Task { @MainActor in self.activeProcess = process }
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        } onCancel: {
            Task { @MainActor in self.activeProcess?.terminate() }
        }
    }

    private func enabledFormats() -> [AudioFormat] {
        AudioFormat.allCases.filter { UserDefaults.standard.bool(forKey: $0.defaultsKey) }
    }

    private func render(_ format: String, snapshot: DiscSnapshot, track: CDTrack?) -> String {
        format
            .replacingOccurrences(of: "%A", with: track?.artist.isEmpty == false ? track!.artist : snapshot.artist)
            .replacingOccurrences(of: "%L", with: snapshot.title)
            .replacingOccurrences(of: "%N", with: String(format: "%02d", track?.id ?? 0))
            .replacingOccurrences(of: "%T", with: track?.title ?? "")
    }

    private func sanitize(_ value: String) -> String {
        value.replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
    }

    nonisolated private static func percentage(in text: String) -> Double? {
        let pattern = #"(\d{1,3})(?:\.\d+)?%"#
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let range = Range(match.range(at: 1), in: text),
              let value = Double(text[range]) else { return nil }
        return min(1, max(0, value / 100))
    }
}

enum RipError: LocalizedError {
    case missingTool(String)
    case commandFailed(String, Int32)

    var errorDescription: String? {
        switch self {
        case .missingTool(let tool): "Required tool is missing: \(tool)."
        case .commandFailed(let command, let status): "\((command as NSString).lastPathComponent) exited with status \(status)."
        }
    }
}
