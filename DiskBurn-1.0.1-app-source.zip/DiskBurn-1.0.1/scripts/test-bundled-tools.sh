#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

project_dir=${0:A:h:h}
bin_dir="$project_dir/dist/DiskBurn.app/Contents/Resources/bin"
test_dir=$(mktemp -d /private/tmp/diskburn-backend-test.XXXXXX)
trap 'rm -rf "$test_dir"' EXIT

run_clean() {
    env -i PATH=/usr/bin:/bin HOME=/private/tmp TMPDIR=/private/tmp "$@"
}

run_clean "$bin_dir/cd-paranoia" --version >/dev/null
run_clean "$bin_dir/ffmpeg" -hide_banner -loglevel error \
    -f lavfi -i "sine=frequency=440:duration=0.25" -ar 44100 -ac 2 \
    "$test_dir/input.wav"
run_clean "$bin_dir/lame" --silent "$test_dir/input.wav" "$test_dir/test.mp3"
run_clean "$bin_dir/oggenc" -Q -o "$test_dir/test.ogg" "$test_dir/input.wav"
run_clean "$bin_dir/flac" -s -f -o "$test_dir/test.flac" "$test_dir/input.wav"
run_clean "$bin_dir/opusenc" --quiet "$test_dir/input.wav" "$test_dir/test.opus"
run_clean "$bin_dir/wavpack" -q "$test_dir/input.wav" -o "$test_dir/test.wv"
run_clean "$bin_dir/mpcenc" --silent "$test_dir/input.wav" "$test_dir/test.mpc"
run_clean "$bin_dir/ffmpeg" -hide_banner -loglevel error -y \
    -i "$test_dir/input.wav" -c:a aac -b:a 192k "$test_dir/test.m4a"
run_clean "$bin_dir/mac" "$test_dir/input.wav" "$test_dir/test.ape" -c3000 >/dev/null

/usr/bin/file "$test_dir"/test.*

for executable in "$bin_dir"/* "$project_dir/dist/DiskBurn.app/Contents/Resources/lib"/*; do
    if /usr/bin/otool -L "$executable" | /usr/bin/tail -n +2 | /usr/bin/awk '{print $1}' | \
        /usr/bin/grep -E '^/opt/homebrew/' >/dev/null; then
        echo "Non-portable Homebrew load path remains in $executable" >&2
        exit 1
    fi
done

echo "All bundled backends passed."
