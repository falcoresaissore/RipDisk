#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

project_dir=${0:A:h:h}
app_dir="$project_dir/dist/DiskBurn.app"
contents="$app_dir/Contents"
binary="$project_dir/.build/manual/DiskBurn"

cd "$project_dir"
"$project_dir/scripts/collect-third-party-licenses.sh"
mkdir -p "$project_dir/.build/manual"
xcrun swiftc "$project_dir"/Sources/DiskBurnMac/*.swift \
  -O -parse-as-library -target arm64-apple-macos14.0 \
  -o "$binary"

mkdir -p "$app_dir"
find "$app_dir" -mindepth 1 -delete
mkdir -p "$contents/MacOS" "$contents/Resources"
cp "$binary" "$contents/MacOS/DiskBurn"
cp "$project_dir/pixmaps/diskburn.png" "$contents/Resources/diskburn.png"
cp "$project_dir/Resources/DiskBurn.icns" "$contents/Resources/DiskBurn.icns"
cp "$project_dir/Resources/ThirdPartyTools.txt" "$contents/Resources/ThirdPartyTools.txt"
ditto "$project_dir/Resources/ThirdPartyLicenses" "$contents/Resources/ThirdPartyLicenses"
cp "$project_dir/THIRD_PARTY_SOURCES.md" "$contents/Resources/THIRD_PARTY_SOURCES.md"
cp "$project_dir/NOTICE" "$contents/Resources/NOTICE"
cp "$project_dir/COPYING" "$contents/Resources/COPYING"
cp "$project_dir/AUTHORS" "$contents/Resources/AUTHORS"
cp "$project_dir/Resources/Info.plist" "$contents/Info.plist"
cp "$project_dir/Resources/PkgInfo" "$contents/PkgInfo"
"$project_dir/scripts/bundle-tools.sh" "$app_dir"

# Do not propagate quarantine/provenance metadata from source assets into the
# locally-built application bundle; Launch Services can otherwise reject it.
xattr -cr "$app_dir"
codesign --force --deep --sign - "$app_dir"
file "$contents/MacOS/DiskBurn"
codesign --verify --deep --strict "$app_dir"
echo "$app_dir"
