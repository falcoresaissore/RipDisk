#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

project_dir=${0:A:h:h}
app_dir="$project_dir/dist/DiskBurn.app"
dmg_path="$project_dir/dist/DiskBurn-1.0.1-arm64.dmg"
dmg_root="$project_dir/.build/dmg-root"
raw_dir=$(mktemp -d "$project_dir/.build/dmg-image.XXXXXX")
raw_image="$raw_dir/DiskBurn-raw.dmg"

"$project_dir/scripts/build-app.sh"

mkdir -p "$dmg_root"
find "$dmg_root" -mindepth 1 -delete
ditto "$app_dir" "$dmg_root/DiskBurn.app"
ln -sfn /Applications "$dmg_root/Applications"
cp "$project_dir/README.md" "$dmg_root/README.md"
cp "$project_dir/COPYING" "$dmg_root/COPYING"
cp "$project_dir/THIRD_PARTY_SOURCES.md" "$dmg_root/THIRD_PARTY_SOURCES.md"

# `hdiutil create` now delegates to DiskManagement on newer macOS releases,
# which is unavailable in some build environments. Creating an HFS image and
# converting it produces the same compressed, checksummed UDZO deliverable.
hdiutil makehybrid \
  -hfs \
  -hfs-volume-name "DiskBurn" \
  -o "$raw_image" \
  "$dmg_root"

hdiutil convert "$raw_image" \
  -format UDZO \
  -ov \
  -o "$dmg_path"

hdiutil verify "$dmg_path"
echo "$dmg_path"
