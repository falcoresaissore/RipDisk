#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

app_dir=${1:?Usage: bundle-tools.sh /path/to/DiskBurn.app}
resources="$app_dir/Contents/Resources"
bin_dir="$resources/bin"
lib_dir="$resources/lib"

tools=(cd-paranoia lame oggenc flac opusenc wavpack mpcenc mac ffmpeg)

mkdir -p "$bin_dir" "$lib_dir"
/usr/bin/find "$bin_dir" "$lib_dir" -mindepth 1 -delete

typeset -A queued source_to_destination
typeset -a sources

resolve_dependency() {
    local dependency=$1
    local source=$2
    local base=${dependency:t}
    local candidate

    case "$dependency" in
        /opt/homebrew/*)
            REPLY=$dependency
            return 0
            ;;
        @loader_path/*)
            candidate="${source:h}/${dependency#@loader_path/}"
            candidate=${candidate:A}
            if [[ -e "$candidate" ]]; then
                REPLY=$candidate
                return 0
            fi
            ;;
        @executable_path/*)
            candidate="/opt/homebrew/bin/${dependency#@executable_path/}"
            candidate=${candidate:A}
            if [[ -e "$candidate" ]]; then
                REPLY=$candidate
                return 0
            fi
            ;;
        @rpath/*)
            ;;
        *)
            return 1
            ;;
    esac

    local -a matches
    matches=(
        /opt/homebrew/lib/$base(N)
        /opt/homebrew/opt/*/lib/$base(N)
        /opt/homebrew/Cellar/*/*/lib/$base(N)
        /opt/homebrew/Cellar/*/*/lib/*/$base(N)
    )
    if (( ${#matches[@]} > 0 )); then
        REPLY=${matches[1]:A}
        return 0
    fi

    return 1
}

enqueue() {
    local source=${1:A}
    local destination=$2
    if [[ -z ${queued[$source]-} ]]; then
        queued[$source]=1
        source_to_destination[$source]=$destination
        sources+=("$source")
    fi
}

for tool in $tools; do
    source_path="/opt/homebrew/bin/$tool"
    if [[ ! -x "$source_path" ]]; then
        echo "Required build-time tool is missing: $source_path" >&2
        exit 1
    fi
    enqueue "$source_path" "$bin_dir/$tool"
done

index=1
while (( index <= ${#sources[@]} )); do
    source=${sources[$index]}
    while IFS= read -r dependency; do
        [[ -z "$dependency" ]] && continue
        case "$dependency" in
            /System/*|/usr/lib/*) continue ;;
        esac
        if resolve_dependency "$dependency" "$source"; then
            library_source=$REPLY
            enqueue "$library_source" "$lib_dir/${library_source:t}"
        else
            echo "Could not resolve dependency '$dependency' required by '$source'" >&2
            exit 1
        fi
    done < <(/usr/bin/otool -L "$source" | /usr/bin/tail -n +2 | /usr/bin/awk '{print $1}')
    (( index += 1 ))
done

for source in $sources; do
    destination=${source_to_destination[$source]}
    /bin/cp -L "$source" "$destination"
    /bin/chmod u+w,go-w "$destination"
    /usr/bin/codesign --remove-signature "$destination" 2>/dev/null || true
done

for source in $sources; do
    destination=${source_to_destination[$source]}
    while IFS= read -r dependency; do
        [[ -z "$dependency" ]] && continue
        case "$dependency" in
            /System/*|/usr/lib/*) continue ;;
        esac
        resolve_dependency "$dependency" "$source"
        library_source=$REPLY
        if [[ "$destination" == "$bin_dir"/* ]]; then
            replacement="@loader_path/../lib/${library_source:t}"
        else
            replacement="@loader_path/${library_source:t}"
        fi
        /usr/bin/install_name_tool -change "$dependency" "$replacement" "$destination"
    done < <(/usr/bin/otool -L "$source" | /usr/bin/tail -n +2 | /usr/bin/awk '{print $1}')

    if [[ "$destination" == "$lib_dir"/* ]]; then
        /usr/bin/install_name_tool -id "@loader_path/${destination:t}" "$destination"
    fi
    /usr/bin/codesign --force --sign - "$destination"
done

echo "Bundled ${#tools[@]} tools and $((${#sources[@]} - ${#tools[@]})) libraries."
