#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

project_dir=${0:A:h:h}
manifest="$project_dir/third_party/SHA256SUMS"

cd "$project_dir/third_party"
shasum -a 256 -c "$manifest"

