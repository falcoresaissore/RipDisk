// swift-tools-version: 5.10
// SPDX-License-Identifier: GPL-2.0-only
import PackageDescription

let package = Package(
    name: "DiskBurn",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "DiskBurn", targets: ["DiskBurnMac"])],
    targets: [
        .executableTarget(
            name: "DiskBurnMac",
            path: "Sources/DiskBurnMac"
        )
    ]
)
