#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

project_dir=${0:A:h:h}
version=1.0.1
release_dir="$project_dir/dist"
stage=$(mktemp -d /private/tmp/ripdisk-release.XXXXXX)
trap 'rm -rf "$stage"' EXIT

cd "$project_dir"
./scripts/verify-third-party-sources.sh
./scripts/collect-third-party-licenses.sh
./scripts/build-dmg.sh
./scripts/test-bundled-tools.sh

source_root="$stage/RipDisk-$version-source"
mkdir -p "$source_root"
ditto --norsrc --noextattr "$project_dir" "$source_root"
rm -rf "$source_root/.build" "$source_root/.git" "$source_root/dist"
find "$source_root" -name .DS_Store -delete
mkdir -p "$source_root/third_party/sources"
cp "$project_dir"/third_party/sources/* "$source_root/third_party/sources/"

source_archive="$release_dir/RipDisk-$version-corresponding-source.tar.gz"
COPYFILE_DISABLE=1 tar -czf "$source_archive" -C "$stage" "${source_root:t}"

cd "$release_dir"
shasum -a 256 \
  "RipDisk-$version-arm64.dmg" \
  "RipDisk-$version-corresponding-source.tar.gz" \
  > "SHA256SUMS.txt"

echo "GitHub release assets:"
echo "$release_dir/RipDisk-$version-arm64.dmg"
echo "$source_archive"
echo "$release_dir/SHA256SUMS.txt"

