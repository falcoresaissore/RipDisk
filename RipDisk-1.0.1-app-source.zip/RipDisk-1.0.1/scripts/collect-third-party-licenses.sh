#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -euo pipefail

project_dir=${0:A:h:h}
destination="$project_dir/Resources/ThirdPartyLicenses"
temporary=$(mktemp -d /private/tmp/ripdisk-licenses.XXXXXX)
trap 'rm -rf "$temporary"' EXIT

formulae=(
  libcdio-paranoia libcdio lame mpg123 vorbis-tools libvorbis libogg flac
  opus-tools libopusenc opus wavpack musepack libcuefile libreplaygain mac
  ffmpeg svt-av1 openssl@4 dav1d xz libvmaf libvpx x264 x265
)

mkdir -p "$destination"
find "$destination" -mindepth 1 -delete

for formula in $formulae; do
  prefix=$(/opt/homebrew/bin/brew --prefix "$formula")
  prefix=${prefix:A}
  formula_destination="$destination/${formula//@/}"
  mkdir -p "$formula_destination"
  while IFS= read -r licence; do
    cp "$licence" "$formula_destination/${licence:t}"
  done < <(find "$prefix" -maxdepth 5 -type f \
    \( -iname 'COPYING*' -o -iname 'LICENSE*' -o -iname 'NOTICE*' \) \
    ! -path '*/share/doc/*' -print | sort)
done

# Homebrew's Musepack and ReplayGain kegs omit their source licence documents.
# Prefer the exact corresponding-source archive when it is present in a release
# workspace. The app-source archive intentionally omits upstream tarballs, so
# retain a checked-in copy of the same BSD notice for local app/DMG builds.
musepack_source="$project_dir/third_party/sources/musepack_src_r475.tar.gz"
if [[ -f "$musepack_source" ]]; then
  tar -xf "$musepack_source" -C "$temporary"
  cp "$temporary/musepack_src_r475/libmpcdec/COPYING" \
    "$destination/musepack/COPYING-libmpcdec"
else
  cp "$project_dir/Resources/LicenseFallbacks/musepack-COPYING" \
    "$destination/musepack/COPYING-libmpcdec"
fi
cp "$destination/ffmpeg/COPYING.LGPLv2.1" \
  "$destination/libreplaygain/LGPL-2.1-reference.txt"
find "$destination" -type f -exec chmod 0644 {} +

echo "Collected third-party licence texts in $destination"

