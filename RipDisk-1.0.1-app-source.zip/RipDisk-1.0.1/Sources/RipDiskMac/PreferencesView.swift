// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 RipDisk contributors
// RipDisk macOS port, derived from Asunder 3.0.1.
import AppKit
import SwiftUI

struct PreferencesView: View {
    var body: some View {
        TabView {
            GeneralPreferencesView()
                .tabItem { Label("General", systemImage: "gearshape") }
            FilenamePreferencesView()
                .tabItem { Label("Filenames", systemImage: "textformat") }
            EncodePreferencesView()
                .tabItem { Label("Encode", systemImage: "waveform") }
            AdvancedPreferencesView()
                .tabItem { Label("Advanced", systemImage: "slider.horizontal.3") }
        }
        .padding(20)
    }
}

struct GeneralPreferencesView: View {
    @AppStorage(PreferenceKey.outputDirectory) private var outputDirectory = ""
    @AppStorage(PreferenceKey.createPlaylist) private var createPlaylist = true
    @AppStorage(PreferenceKey.device) private var device = "default"
    @AppStorage(PreferenceKey.ejectWhenFinished) private var ejectWhenFinished = false
    @AppStorage(PreferenceKey.appearance) private var appearance = "system"

    var body: some View {
        Form {
            Section("Destination") {
                HStack {
                    TextField("Destination folder", text: $outputDirectory)
                    Button("Choose…") { chooseFolder() }
                }
                Toggle("Create M3U playlist", isOn: $createPlaylist)
            }
            Section("Appearance") {
                Picker("Colour scheme", selection: $appearance) {
                    Text("System").tag("system")
                    Text("Light").tag("light")
                    Text("Dark").tag("dark")
                }
                .pickerStyle(.segmented)
                .onChange(of: appearance) { _, newValue in
                    Appearance.apply(newValue)
                }
            }
            Section("CD Drive") {
                TextField("Device", text: $device)
                Text("Use “default” to let macOS and libcdio select the optical drive.")
                    .font(.caption).foregroundStyle(.secondary)
                Toggle("Eject disc when finished", isOn: $ejectWhenFinished)
            }
            Spacer()
        }
        .formStyle(.grouped)
        .onAppear {
            Appearance.apply(appearance)
        }
    }

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url { outputDirectory = url.path }
    }
}

struct FilenamePreferencesView: View {
    @AppStorage(PreferenceKey.albumDirectoryFormat) private var album = "%A - %L"
    @AppStorage(PreferenceKey.playlistFormat) private var playlist = "%A - %L"
    @AppStorage(PreferenceKey.musicFileFormat) private var music = "%N - %A - %T"

    var body: some View {
        Form {
            Section("Filename formats") {
                LabeledContent("Album directory") { TextField("", text: $album) }
                LabeledContent("Playlist file") { TextField("", text: $playlist) }
                LabeledContent("Music file") { TextField("", text: $music) }
            }
            Section("Placeholders") {
                Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 6) {
                    GridRow { Text("%A").monospaced(); Text("Artist") }
                    GridRow { Text("%L").monospaced(); Text("Album") }
                    GridRow { Text("%N").monospaced(); Text("Track number (2-digit)") }
                    GridRow { Text("%T").monospaced(); Text("Song title") }
                }
            }
            Spacer()
        }
        .formStyle(.grouped)
    }
}

struct EncodePreferencesView: View {
    @AppStorage(AudioFormat.wav.defaultsKey) private var wav = false
    @AppStorage(AudioFormat.mp3.defaultsKey) private var mp3 = false
    @AppStorage(AudioFormat.ogg.defaultsKey) private var ogg = true
    @AppStorage(AudioFormat.flac.defaultsKey) private var flac = false
    @AppStorage(AudioFormat.opus.defaultsKey) private var opus = false
    @AppStorage(AudioFormat.wavpack.defaultsKey) private var wavpack = false
    @AppStorage(AudioFormat.musepack.defaultsKey) private var musepack = false
    @AppStorage(AudioFormat.aac.defaultsKey) private var aac = false
    @AppStorage(AudioFormat.monkeysAudio.defaultsKey) private var monkeysAudio = false
    @AppStorage(PreferenceKey.mp3VBR) private var mp3VBR = true
    @AppStorage(PreferenceKey.mp3Bitrate) private var mp3Bitrate = 190
    @AppStorage(PreferenceKey.oggQuality) private var oggQuality = 6.0
    @AppStorage(PreferenceKey.flacCompression) private var flacCompression = 5
    @AppStorage(PreferenceKey.opusBitrate) private var opusBitrate = 160
    @AppStorage(PreferenceKey.aacBitrate) private var aacBitrate = 192

    var body: some View {
        Form {
            formatToggle("WAV (uncompressed)", value: $wav, command: nil)
            formatToggle("MP3 (lossy compression)", value: $mp3, command: "lame")
            if mp3 {
                Toggle("Variable bit rate (VBR)", isOn: $mp3VBR)
                LabeledContent("Bitrate") { Stepper("\(mp3Bitrate) kbps", value: $mp3Bitrate, in: 64...320, step: 16) }
            }
            formatToggle("Ogg Vorbis (lossy compression)", value: $ogg, command: "oggenc")
            if ogg { LabeledContent("Quality") { Slider(value: $oggQuality, in: -1...10, step: 1); Text(oggQuality, format: .number.precision(.fractionLength(0))) } }
            formatToggle("FLAC (lossless compression)", value: $flac, command: "flac")
            if flac { LabeledContent("Compression") { Stepper("\(flacCompression)", value: $flacCompression, in: 0...8) } }
            formatToggle("Opus", value: $opus, command: "opusenc")
            if opus { LabeledContent("Bitrate") { Stepper("\(opusBitrate) kbps", value: $opusBitrate, in: 32...512, step: 16) } }
            DisclosureGroup("More formats") {
                formatToggle("WavPack", value: $wavpack, command: "wavpack")
                formatToggle("Musepack", value: $musepack, command: "mpcenc")
                formatToggle("AAC", value: $aac, command: "ffmpeg")
                if aac { LabeledContent("Bitrate") { Stepper("\(aacBitrate) kbps", value: $aacBitrate, in: 64...512, step: 16) } }
                formatToggle("Monkey's Audio", value: $monkeysAudio, command: "mac")
            }
        }
        .formStyle(.grouped)
    }

    private func formatToggle(_ title: String, value: Binding<Bool>, command: String?) -> some View {
        HStack {
            Toggle(title, isOn: value)
            Spacer()
            if let command {
                let found = CommandRunner.locate(command) != nil
                Label(found ? "Available" : "Missing", systemImage: found ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(found ? .green : .orange)
            }
        }
    }
}

struct AdvancedPreferencesView: View {
    @AppStorage(PreferenceKey.automaticMetadata) private var automaticMetadata = true
    @AppStorage(PreferenceKey.cddbServer) private var cddbServer = "gnudb.gnudb.org"
    @AppStorage(PreferenceKey.cddbPort) private var cddbPort = 443
    @AppStorage(PreferenceKey.cddbIdentity) private var cddbIdentity = ""
    @AppStorage(PreferenceKey.fastRip) private var fastRip = true
    @AppStorage(PreferenceKey.logEnabled) private var logEnabled = false

    var body: some View {
        Form {
            Section("CDDB") {
                Toggle("Get disc information from the internet automatically", isOn: $automaticMetadata)
                LabeledContent("Server") { TextField("", text: $cddbServer) }
                LabeledContent("HTTPS port") {
                    TextField("443", text: Binding(
                        get: { String(cddbPort) },
                        set: { value in
                            let digits = value.filter(\.isNumber)
                            if let port = Int(digits), (1...65535).contains(port) { cddbPort = port }
                        }
                    ))
                    .frame(width: 90)
                    .monospacedDigit()
                }
                LabeledContent("Identity / email") { TextField("", text: $cddbIdentity) }
                Text("GNUDB uses this identity for CDDB requests. You can replace the generated value with your registered GNUDB email or unique code.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Section("Ripping") {
                Toggle("Fast ripping (-Z)", isOn: $fastRip)
                Toggle("Write diagnostic log", isOn: $logEnabled)
                LabeledContent("Ripper") {
                    Text(CommandRunner.locate("cd-paranoia") ?? "Not installed")
                        .foregroundStyle(CommandRunner.locate("cd-paranoia") == nil ? .orange : .secondary)
                        .lineLimit(1)
                }
            }
            Spacer()
        }
        .formStyle(.grouped)
    }
}
