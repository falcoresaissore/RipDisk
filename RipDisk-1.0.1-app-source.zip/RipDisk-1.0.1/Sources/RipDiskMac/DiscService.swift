// SPDX-License-Identifier: GPL-2.0-only
// Copyright (C) 2026 RipDisk contributors
// RipDisk macOS port, derived from Asunder 3.0.1.
import Foundation
import IOKit

enum DiscServiceError: LocalizedError {
    case noDrive
    case noAudioDisc(String)
    case invalidTOC

    var errorDescription: String? {
        switch self {
        case .noDrive: "No optical drive was detected. Connect a CD drive and insert an audio CD."
        case .noAudioDisc(let detail): detail.isEmpty ? "No audio CD was detected." : detail
        case .invalidTOC: "The CD table of contents could not be read."
        }
    }
}

struct CommandResult {
    let status: Int32
    let standardOutput: String
    let standardError: String
}

enum CommandRunner {
    static func locate(_ command: String) -> String? {
        var candidates: [String] = []
        if let resources = Bundle.main.resourceURL {
            candidates.append(resources.appendingPathComponent("bin/\(command)").path)
        }
        candidates.append(contentsOf: [
            "/opt/homebrew/bin/\(command)",
            NSHomeDirectory() + "/homebrew-ripdisk/bin/\(command)",
            NSHomeDirectory() + "/homebrew-asunder/bin/\(command)",
            "/usr/local/bin/\(command)",
            "/usr/bin/\(command)"
        ])
        if let match = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) {
            return match
        }
        let paths = ProcessInfo.processInfo.environment["PATH"]?.split(separator: ":").map(String.init) ?? []
        return paths.map { "\($0)/\(command)" }.first(where: { FileManager.default.isExecutableFile(atPath: $0) })
    }

    static func run(_ executable: String, _ arguments: [String]) throws -> CommandResult {
        let process = Process()
        let output = Pipe()
        let error = Pipe()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = output
        process.standardError = error
        try process.run()
        process.waitUntilExit()
        return CommandResult(
            status: process.terminationStatus,
            standardOutput: String(decoding: output.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self),
            standardError: String(decoding: error.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self)
        )
    }
}

enum DiscService {
    static func readDisc() async throws -> DiscSnapshot {
        try await Task.detached(priority: .userInitiated) {
            if let disc = try readIOKitDisc() {
                return disc
            }

            // Keep drutil as a fallback for older Macs and internal drives.
            let list = try CommandRunner.run("/usr/bin/drutil", ["list"])
            guard list.standardOutput.split(separator: "\n").count > 2 else {
                throw DiscServiceError.noDrive
            }

            let toc = try CommandRunner.run("/usr/bin/drutil", ["toc"])
            guard toc.status == 0 else {
                throw DiscServiceError.noAudioDisc(toc.standardError.trimmingCharacters(in: .whitespacesAndNewlines))
            }
            return try parseTOC(toc.standardOutput)
        }.value
    }

    static func eject(devicePath: String? = nil) {
        Task.detached {
            if let devicePath {
                let blockDevice = devicePath.replacingOccurrences(of: "/dev/rdisk", with: "/dev/disk")
                let result = try? CommandRunner.run("/usr/sbin/diskutil", ["eject", blockDevice])
                if result?.status == 0 { return }
            }
            _ = try? CommandRunner.run("/usr/bin/drutil", ["tray", "eject"])
        }
    }

    private static func readIOKitDisc() throws -> DiscSnapshot? {
        var iterator: io_iterator_t = 0
        let status = IOServiceGetMatchingServices(
            kIOMainPortDefault,
            IOServiceMatching("IOCDMedia"),
            &iterator
        )
        guard status == KERN_SUCCESS else { return nil }
        defer { IOObjectRelease(iterator) }

        var sawDrive = false
        while true {
            let service = IOIteratorNext(iterator)
            guard service != 0 else { break }
            defer { IOObjectRelease(service) }
            sawDrive = true

            guard let bsdName = registryProperty("BSD Name", service: service) as? String,
                  let toc = registryProperty("TOC", service: service) as? Data else { continue }
            if let disc = try parseBinaryTOC(toc, devicePath: "/dev/r\(bsdName)") {
                return disc
            }
        }

        if sawDrive { throw DiscServiceError.noAudioDisc("The optical drive is present, but no readable audio CD was found.") }
        return nil
    }

    private static func registryProperty(_ key: String, service: io_registry_entry_t) -> Any? {
        IORegistryEntryCreateCFProperty(
            service,
            key as CFString,
            kCFAllocatorDefault,
            0
        )?.takeRetainedValue()
    }

    private static func parseBinaryTOC(_ data: Data, devicePath: String) throws -> DiscSnapshot? {
        let bytes = [UInt8](data)
        guard bytes.count >= 15 else { return nil }

        var starts: [(number: Int, frame: Int)] = []
        var leadout: Int?
        for offset in stride(from: 4, through: bytes.count - 11, by: 11) {
            let control = bytes[offset + 1] & 0x0f
            let point = bytes[offset + 3]
            let frame = (Int(bytes[offset + 8]) * 60 + Int(bytes[offset + 9])) * 75 + Int(bytes[offset + 10])

            if point >= 1 && point <= 99, control & 0x04 == 0 {
                starts.append((Int(point), frame))
            } else if point == 0xa2 {
                leadout = frame
            }
        }

        starts.sort { $0.number < $1.number }
        guard !starts.isEmpty, let leadout else { return nil }
        let tracks = starts.enumerated().map { index, item in
            let end = index + 1 < starts.count ? starts[index + 1].frame : leadout
            return CDTrack(
                id: item.number,
                title: String(format: "Track %02d", item.number),
                duration: Double(max(0, end - item.frame)) / 75.0,
                frameOffset: item.frame
            )
        }
        return DiscSnapshot(tracks: tracks, leadoutFrame: leadout, devicePath: devicePath)
    }

    private static func parseTOC(_ text: String) throws -> DiscSnapshot {
        // drutil prints track rows containing a track number followed by MSF fields.
        let timePattern = #"(\d{1,3}):(\d{2}):(\d{2})"#
        let regex = try NSRegularExpression(pattern: timePattern)
        var tracks: [CDTrack] = []
        var leadout = 0

        for line in text.split(separator: "\n").map(String.init) {
            let range = NSRange(line.startIndex..., in: line)
            let matches = regex.matches(in: line, range: range)
            guard !matches.isEmpty else { continue }
            let values = matches.compactMap { match -> Int? in
                guard match.numberOfRanges == 4,
                      let m = Range(match.range(at: 1), in: line),
                      let s = Range(match.range(at: 2), in: line),
                      let f = Range(match.range(at: 3), in: line) else { return nil }
                return ((Int(line[m]) ?? 0) * 60 + (Int(line[s]) ?? 0)) * 75 + (Int(line[f]) ?? 0)
            }
            guard let number = line.split(whereSeparator: { $0 == " " || $0 == "\t" }).compactMap({ Int($0) }).first,
                  let start = values.first else { continue }
            let durationFrames = values.count > 1 ? values.last! : 0
            if number >= 1 && number <= 99 {
                tracks.append(CDTrack(id: number, title: String(format: "Track %02d", number), duration: Double(durationFrames) / 75.0, frameOffset: start + 150))
                leadout = max(leadout, start + durationFrames + 150)
            }
        }

        guard !tracks.isEmpty else { throw DiscServiceError.invalidTOC }
        tracks.sort { $0.id < $1.id }
        return DiscSnapshot(tracks: tracks, leadoutFrame: leadout)
    }
}

enum CDDBService {
    static func applyMetadata(to snapshot: DiscSnapshot) async -> DiscSnapshot {
        guard UserDefaults.standard.bool(forKey: PreferenceKey.automaticMetadata) else { return snapshot }
        return (try? await fetchMetadata(for: snapshot)) ?? snapshot
    }

    static func fetchMetadata(for snapshot: DiscSnapshot) async throws -> DiscSnapshot {
        let server = UserDefaults.standard.string(forKey: PreferenceKey.cddbServer) ?? "gnudb.gnudb.org"
        let port = UserDefaults.standard.integer(forKey: PreferenceKey.cddbPort)
        let identity = UserDefaults.standard.string(forKey: PreferenceKey.cddbIdentity) ?? "ripdisk@localhost"
        let identityParts = identity.split(separator: "@", maxSplits: 1).map(String.init)
        let user = identityParts.first?.isEmpty == false ? identityParts[0] : "ripdisk"
        let host = identityParts.count == 2 && !identityParts[1].isEmpty ? identityParts[1] : "localhost"
        // Retain Asunder's registered GNUDB protocol identity for compatibility.
        let hello = [user, host, "Asunder", "3.0.1"]
            .map { $0.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? $0 }
            .joined(separator: "+")
        let offsets = snapshot.tracks.map { String($0.frameOffset) }.joined(separator: "+")
        let firstSeconds = (snapshot.tracks.first?.frameOffset ?? 150) / 75
        let length = max(0, snapshot.leadoutFrame / 75 - firstSeconds)
        let command = "cddb+query+\(snapshot.discID)+\(snapshot.tracks.count)+\(offsets)+\(length)"
        guard let queryURL = endpoint(server: server, port: port, command: command, hello: hello) else {
            throw CDDBError.invalidServer
        }

        let (queryData, queryResponse) = try await URLSession.shared.data(from: queryURL)
        guard (queryResponse as? HTTPURLResponse)?.statusCode == 200 else {
            throw CDDBError.connectionFailed
        }
        let queryText = String(decoding: queryData, as: UTF8.self)
        let lines = responseLines(queryText)
        guard let status = lines.first else { throw CDDBError.invalidResponse("Empty response") }
        if status.hasPrefix("202 ") { throw CDDBError.noMatch }
        if status.first?.isNumber == true, !status.hasPrefix("200 "), !status.hasPrefix("210 "), !status.hasPrefix("211 ") {
            throw CDDBError.serverMessage(status)
        }

        let match: String?
        if status.hasPrefix("200 ") {
            match = status
        } else if status.hasPrefix("210 ") || status.hasPrefix("211 ") {
            match = lines.dropFirst().first(where: { !$0.isEmpty && $0 != "." })
        } else {
            throw CDDBError.invalidResponse(status)
        }
        guard let match else { throw CDDBError.invalidResponse(status) }
        let fields = match.split(separator: " ", maxSplits: 3).map(String.init)
        let fieldOffset = match.hasPrefix("200 ") ? 1 : 0
        guard fields.count >= fieldOffset + 2 else { throw CDDBError.invalidResponse(match) }
        let category = fields[fieldOffset]
        let discID = fields[fieldOffset + 1]
        let readCommand = "cddb+read+\(category)+\(discID)"
        guard let readURL = endpoint(server: server, port: port, command: readCommand, hello: hello) else {
            throw CDDBError.invalidServer
        }
        let (readData, readResponse) = try await URLSession.shared.data(from: readURL)
        guard (readResponse as? HTTPURLResponse)?.statusCode == 200 else {
            throw CDDBError.connectionFailed
        }
        let readText = String(decoding: readData, as: UTF8.self)
        guard readText.hasPrefix("210 ") else {
            throw CDDBError.serverMessage(responseLines(readText).first ?? "Invalid response")
        }
        return parseMetadata(readText, into: snapshot)
    }

    private static func endpoint(server: String, port: Int, command: String, hello: String) -> URL? {
        var components = URLComponents()
        components.scheme = port == 80 ? "http" : "https"
        components.host = server
            .replacingOccurrences(of: "https://", with: "")
            .replacingOccurrences(of: "http://", with: "")
            .trimmingCharacters(in: CharacterSet(charactersIn: "/ "))
        components.port = port > 0 ? port : 443
        components.path = "/~cddb/cddb.cgi"
        components.percentEncodedQuery = "cmd=\(command)&hello=\(hello)&proto=6"
        return components.url
    }

    private static func responseLines(_ text: String) -> [String] {
        text.components(separatedBy: .newlines).filter { !$0.isEmpty }
    }

    private static func parseMetadata(_ text: String, into original: DiscSnapshot) -> DiscSnapshot {
        var snapshot = original
        var titles: [Int: String] = [:]
        var artists: [Int: String] = [:]
        for line in responseLines(text) {
            if line.hasPrefix("DTITLE=") {
                let parts = String(line.dropFirst(7)).components(separatedBy: " / ")
                snapshot.artist = parts.first ?? snapshot.artist
                snapshot.title = parts.dropFirst().joined(separator: " / ")
            } else if line.hasPrefix("DYEAR=") {
                snapshot.year = String(line.dropFirst(6))
            } else if line.hasPrefix("DGENRE=") {
                snapshot.genre = String(line.dropFirst(7))
            } else if line.hasPrefix("TTITLE"), let equals = line.firstIndex(of: "=") {
                let key = line[..<equals].dropFirst(6)
                guard let index = Int(key) else { continue }
                let value = String(line[line.index(after: equals)...])
                let parts = value.components(separatedBy: " / ")
                titles[index] = parts.last ?? value
                if parts.count > 1 { artists[index] = parts[0] }
            }
        }
        for index in snapshot.tracks.indices {
            snapshot.tracks[index].title = titles[index] ?? snapshot.tracks[index].title
            snapshot.tracks[index].artist = artists[index] ?? snapshot.artist
        }
        return snapshot
    }
}

enum CDDBError: LocalizedError {
    case invalidServer
    case connectionFailed
    case invalidResponse(String)
    case noMatch
    case serverMessage(String)

    var errorDescription: String? {
        switch self {
        case .invalidServer: "The GNUDB server address or port is invalid."
        case .connectionFailed: "GNUDB could not be reached. Check the server address, port, and internet connection."
        case .invalidResponse(let detail): "GNUDB returned an invalid response: \(detail)"
        case .noMatch: "GNUDB has no information for this CD."
        case .serverMessage(let message): "GNUDB: \(message)"
        }
    }
}
