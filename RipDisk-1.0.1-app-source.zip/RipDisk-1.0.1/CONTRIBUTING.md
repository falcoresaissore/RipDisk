# Contributing

Contributions are welcome under the project's GPL-2.0-only licence. By
submitting a contribution, you confirm that you have the right to provide it
under those terms and that it may be redistributed as part of RipDisk.

Build and test changes with:

```sh
./scripts/build-app.sh
./scripts/test-bundled-tools.sh
```

Do not commit `.build`, `dist`, downloaded third-party source archives, audio
CD contents, or personal metadata. Keep the third-party source manifest and
licence files current whenever a bundled backend changes.

