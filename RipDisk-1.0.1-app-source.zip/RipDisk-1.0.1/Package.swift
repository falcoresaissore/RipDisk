// swift-tools-version: 5.10
// SPDX-License-Identifier: GPL-2.0-only
import PackageDescription

let package = Package(
    name: "RipDisk",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "RipDisk", targets: ["RipDiskMac"])],
    targets: [
        .executableTarget(
            name: "RipDiskMac",
            path: "Sources/RipDiskMac"
        )
    ]
)
